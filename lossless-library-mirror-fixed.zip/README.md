# Lossless Library Mirror

Lossless Library Mirror unpacks an ALAC music library into PCM WAV files. ALAC
is reversible lossless compression, so this is analogous to unzipping the
original PCM audio rather than changing its sound. The application performs no
resampling, normalization, gain adjustment, filtering, dithering, or channel
remixing. It keeps the artist and album folder structure, preserves the
original sample rate and bit depth, exports artwork, archives metadata, and
verifies the unpacked audio before completing each output file.

The source library is mounted read-only. The application cannot alter it.

## Try the supplied Mac test setup

The included Mac test configuration makes two useful areas available to both
folder choosers:

- The current user's Mac home folder
- Drives mounted below `/Volumes`

The source view of those locations is read-only. The destination view is
writable. This lets the Mac prototype choose a test source and destination
without editing Docker configuration each time.

From this project folder, start it with:

```sh
docker compose -f compose.mac-test.yaml up --build -d
```

Then open [http://localhost:8090](http://localhost:8090).

Use **Choose source** to browse to the ALAC test folder, then use **Choose
destination** to select or create a separate output folder. Use **Preview
library** before starting.

The destination may be new or already contain files. The app places a small
ownership marker there so the same source can safely resume later. Existing
files are preserved, and a conflicting WAV is reported rather than overwritten.

Stop the application with:

```sh
docker compose -f compose.mac-test.yaml down
```

## Use another library or NAS

For a non-UGREEN installation with fixed mount points, copy `.env.example` to
`.env`, fill in the three folder locations, then run:

```sh
docker compose -f compose.custom.yaml up --build -d
```

Open port 8090 on the computer or NAS running Docker.

The installation grants one or more top-level NAS shares to the container.
Inside the web interface, **Browse** buttons let the user navigate those NAS
folders, select the ALAC source, select the WAV destination, and create a new
destination folder. Source shares remain read-only.

## UGREEN NAS: choose everything in the web interface

The supplied `compose.yaml` (also copied as `compose.ugreen.yaml`) is ready for
a UGREEN NAS whose storage is `/volume1`. It
mounts the NAS volume twice: read-only in the source browser and writable in
the destination browser. No particular ALAC or WAV folder is fixed in YAML.

After deployment, open port 8090 and use the web interface to:

1. Browse to any ALAC source folder on Volume1.
2. Browse to any destination location.
3. Create and automatically select a new destination folder.
4. Preview and confirm the exact source and destination before starting.

If the music is stored on `/volume2`, replace both occurrences of `/volume1`
in `compose.ugreen.yaml` with `/volume2`. To browse both volumes, duplicate
both source/destination mount pairs and use distinct targets such as `Volume1`
and `Volume2`.

## Safety and preservation

- The ALAC source is read-only.
- Every source folder and subfolder is recreated with its exact original name,
  including empty folders.
- Track filenames, disc and track numbering, punctuation, spaces, and Unicode
  characters are preserved; only `.m4a` or `.alac` changes to `.wav`.
- Outputs are written to temporary files and renamed only after verification.
- Existing verified WAVs are skipped on subsequent runs.
- Existing WAVs that do not match are reported and never overwritten.
- Common tags are written into the WAV RIFF metadata.
- All original tags are also saved as JSON in each album's `.metadata` folder.
- Existing `cover.jpg`, `cover.png`, or `folder.jpg` files are copied.
- Embedded artwork is exported as `cover.jpg` or `cover.png`.
- A preservation copy is stored in the album's `.cover` folder when enabled.
- Source timestamps are applied to completed WAV files.
