#!/usr/bin/env python3
"""Lossless Library Mirror: ALAC to verified PCM WAV with a small web UI."""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict, dataclass
from http import HTTPStatus
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse


APP_DIR = Path(__file__).resolve().parent
STATIC_DIR = APP_DIR / "static"
SOURCE_ROOT = Path(os.environ.get("SOURCE_ROOT", "/source")).resolve()
DEST_ROOT = Path(os.environ.get("DEST_ROOT", "/destination")).resolve()
CONFIG_ROOT = Path(os.environ.get("CONFIG_ROOT", "/config")).resolve()
PORT = int(os.environ.get("PORT", "8090"))
SOURCE_LABEL = os.environ.get("SOURCE_LABEL", "NAS source folders")
DEST_LABEL = os.environ.get("DEST_LABEL", "NAS destination folders")
SUPPORTED_SUFFIXES = {".m4a", ".alac"}
DESTINATION_MARKER = ".lossless-library-mirror.json"


@dataclass
class Track:
    source: str
    output: str
    artist: str
    album: str
    title: str
    codec: str
    bits: int
    sample_rate: int
    channels: int
    duration: float
    source_bytes: int
    estimated_wav_bytes: int
    has_embedded_art: bool
    state: str = "ready"


class AppState:
    def __init__(self) -> None:
        self.lock = threading.RLock()
        self.stop_event = threading.Event()
        self.job_thread: threading.Thread | None = None
        self.album_art_lock = threading.Lock()
        self.art_done: set[str] = set()
        self.data: dict[str, Any] = {
            "phase": "idle",
            "message": "Ready to scan",
            "tracks": [],
            "total": 0,
            "completed": 0,
            "skipped": 0,
            "failed": 0,
            "active": 0,
            "estimatedBytes": 0,
            "sourceBytes": 0,
            "logs": [],
            "startedAt": None,
            "finishedAt": None,
            "selection": None,
            "previewToken": None,
        }

    def snapshot(self) -> dict[str, Any]:
        with self.lock:
            return json.loads(json.dumps(self.data))

    def update(self, **changes: Any) -> None:
        with self.lock:
            self.data.update(changes)
            self._persist()

    def log(self, message: str, level: str = "info") -> None:
        entry = {
            "time": time.strftime("%H:%M:%S"),
            "level": level,
            "message": message,
        }
        with self.lock:
            self.data["logs"].append(entry)
            self.data["logs"] = self.data["logs"][-250:]
            self._persist()

    def adjust(self, **deltas: int) -> None:
        with self.lock:
            for key, amount in deltas.items():
                self.data[key] = int(self.data.get(key, 0)) + amount
            self._persist()

    def set_track_state(self, source: str, track_state: str) -> None:
        with self.lock:
            for track in self.data.get("tracks", []):
                if track.get("source") == source:
                    track["state"] = track_state
                    break
            self._persist()

    def _persist(self) -> None:
        try:
            CONFIG_ROOT.mkdir(parents=True, exist_ok=True)
            target = CONFIG_ROOT / "state.json"
            temporary = CONFIG_ROOT / ".state.json.tmp"
            temporary.write_text(
                json.dumps({k: v for k, v in self.data.items() if k != "tracks"}, indent=2),
                encoding="utf-8",
            )
            os.replace(temporary, target)
        except OSError:
            pass


STATE = AppState()


def safe_subpath(root: Path, relative: str) -> Path:
    relative = (relative or "").strip().lstrip("/")
    candidate = (root / relative).resolve()
    if candidate != root and root not in candidate.parents:
        raise ValueError("Folder must remain inside the mounted library")
    return candidate


def selection_from_options(options: dict[str, Any]) -> dict[str, str]:
    return {
        "sourceSubdir": str(options.get("sourceSubdir", "")).strip().strip("/"),
        "destinationSubdir": str(options.get("destinationSubdir", "")).strip().strip("/"),
    }


def folder_listing(kind: str, relative: str = "") -> dict[str, Any]:
    if kind not in {"source", "destination"}:
        raise ValueError("Folder kind must be source or destination")
    root = SOURCE_ROOT if kind == "source" else DEST_ROOT
    folder = safe_subpath(root, relative)
    if not folder.is_dir():
        raise ValueError("Folder does not exist")
    current = "" if folder == root else folder.relative_to(root).as_posix()
    parent_path = None
    if folder != root:
        parent = folder.parent
        parent_path = "" if parent == root else parent.relative_to(root).as_posix()
    children = [
        {
            "name": child.name,
            "path": child.relative_to(root).as_posix(),
        }
        for child in sorted(folder.iterdir(), key=lambda item: item.name.casefold())
        if child.is_dir() and not child.name.startswith(".")
    ]
    return {
        "kind": kind,
        "current": current,
        "parent": parent_path,
        "folders": children,
        "canCreate": kind == "destination",
    }


def create_destination_folder(parent_relative: str, name: str) -> dict[str, Any]:
    clean_name = name.strip()
    if (
        not clean_name
        or clean_name in {".", ".."}
        or "/" in clean_name
        or "\\" in clean_name
        or clean_name.startswith(".")
    ):
        raise ValueError("Enter a single visible folder name")
    parent = safe_subpath(DEST_ROOT, parent_relative)
    if not parent.is_dir():
        raise ValueError("Parent destination folder does not exist")
    new_folder = safe_subpath(DEST_ROOT, str(Path(parent_relative) / clean_name))
    new_folder.mkdir(exist_ok=False)
    return folder_listing("destination", new_folder.relative_to(DEST_ROOT).as_posix())


def claim_destination(source_dir: Path, destination_dir: Path) -> None:
    """Claim a destination while preserving any files already present."""
    validate_destination(source_dir, destination_dir)

    marker = destination_dir / DESTINATION_MARKER
    if marker.exists():
        return

    contents = [item for item in destination_dir.iterdir() if item.name != ".DS_Store"]
    temporary = destination_dir / f".{DESTINATION_MARKER}.tmp"
    temporary.write_text(
        json.dumps(
            {
                "application": "Lossless Library Mirror",
                "source": str(source_dir.resolve()),
                "createdAt": time.time(),
                "adoptedExistingFolder": bool(contents),
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    os.replace(temporary, marker)


def validate_destination(source_dir: Path, destination_dir: Path) -> None:
    """Fail quickly only when a destination is unavailable or owned by another source."""
    if not destination_dir.is_dir():
        raise ValueError("Destination folder does not exist. Create or choose it first.")

    marker = destination_dir / DESTINATION_MARKER
    source_identity = str(source_dir.resolve())
    if marker.exists():
        try:
            existing = json.loads(marker.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise ValueError("Destination safety marker is damaged; choose a new empty folder.") from exc
        if existing.get("source") != source_identity:
            raise ValueError(
                "This destination belongs to a different source library. "
                "Choose a new empty folder."
            )
        return


def run_command(command: list[str], timeout: int | None = None) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command,
        check=True,
        capture_output=True,
        text=True,
        timeout=timeout,
    )


def probe_file(path: Path) -> dict[str, Any]:
    result = run_command(
        [
            "ffprobe",
            "-v",
            "error",
            "-show_entries",
            "format=duration,size:format_tags:stream=index,codec_name,codec_type,"
            "sample_fmt,sample_rate,channels,bits_per_raw_sample",
            "-of",
            "json",
            str(path),
        ],
        timeout=60,
    )
    return json.loads(result.stdout)


def audio_stream(probe: dict[str, Any]) -> dict[str, Any]:
    for stream in probe.get("streams", []):
        if stream.get("codec_type") == "audio":
            return stream
    raise ValueError("No audio stream found")


def pcm_codec_for_bits(bits: int) -> str:
    if bits <= 16:
        return "pcm_s16le"
    if bits <= 24:
        return "pcm_s24le"
    return "pcm_s32le"


def scan_library(source_subdir: str = "", destination_subdir: str = "") -> list[Track]:
    source_dir = safe_subpath(SOURCE_ROOT, source_subdir)
    destination_dir = safe_subpath(DEST_ROOT, destination_subdir)
    if not source_dir.is_dir():
        raise ValueError(f"Source folder is unavailable: {source_dir}")
    if not destination_dir.is_dir():
        raise ValueError(f"Destination folder is unavailable: {destination_dir}")

    files = sorted(
        path
        for path in source_dir.rglob("*")
        if path.is_file() and path.suffix.lower() in SUPPORTED_SUFFIXES
    )
    tracks: list[Track] = []
    STATE.update(phase="scanning", message=f"Inspecting {len(files)} audio files")

    for index, path in enumerate(files, start=1):
        try:
            probe = probe_file(path)
            stream = audio_stream(probe)
            if stream.get("codec_name") != "alac":
                STATE.log(f"Skipped non-ALAC file: {path.relative_to(source_dir)}", "warning")
                continue

            tags = probe.get("format", {}).get("tags", {})
            relative = path.relative_to(source_dir)
            output_relative = relative.with_suffix(".wav")
            bits = int(stream.get("bits_per_raw_sample") or 0)
            if not bits:
                bits = 16 if "16" in str(stream.get("sample_fmt", "")) else 24
            rate = int(stream.get("sample_rate") or 0)
            channels = int(stream.get("channels") or 0)
            duration = float(probe.get("format", {}).get("duration") or 0)
            source_bytes = int(probe.get("format", {}).get("size") or path.stat().st_size)
            estimate = int(duration * rate * channels * bits / 8) + 4096
            has_art = any(
                item.get("codec_type") == "video" for item in probe.get("streams", [])
            )
            output_path = destination_dir / output_relative
            tracks.append(
                Track(
                    source=str(relative),
                    output=str(output_relative),
                    artist=tags.get("album_artist") or tags.get("artist") or relative.parts[0],
                    album=tags.get("album") or relative.parent.name,
                    title=tags.get("title") or path.stem,
                    codec="ALAC",
                    bits=bits,
                    sample_rate=rate,
                    channels=channels,
                    duration=duration,
                    source_bytes=source_bytes,
                    estimated_wav_bytes=estimate,
                    has_embedded_art=has_art,
                    state="existing" if output_path.exists() else "ready",
                )
            )
        except Exception as exc:
            STATE.log(f"Could not inspect {path.name}: {exc}", "error")
        if index % 10 == 0 or index == len(files):
            STATE.update(message=f"Inspected {index} of {len(files)} files")

    return tracks


def decoded_hash(path: Path, pcm_codec: str) -> str:
    result = run_command(
        [
            "ffmpeg",
            "-nostdin",
            "-v",
            "error",
            "-i",
            str(path),
            "-map",
            "0:a:0",
            "-c:a",
            pcm_codec,
            "-f",
            "hash",
            "-hash",
            "sha256",
            "-",
        ],
        timeout=1800,
    )
    return result.stdout.strip()


def copy_file_atomically(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(f".{destination.name}.partial")
    shutil.copy2(source, temporary)
    os.replace(temporary, destination)


def mirror_directory_tree(source_dir: Path, destination_dir: Path) -> list[tuple[Path, Path]]:
    """Create every source directory at the same relative destination path."""
    mirrored: list[tuple[Path, Path]] = []
    for current, directories, _files in os.walk(source_dir):
        directories.sort()
        source_path = Path(current)
        destination_path = destination_dir / source_path.relative_to(source_dir)
        destination_path.mkdir(parents=True, exist_ok=True)
        mirrored.append((source_path, destination_path))
    return mirrored


def preserve_directory_timestamps(mirrored: list[tuple[Path, Path]]) -> None:
    """Apply timestamps after writing children, from deepest directory upward."""
    for source_path, destination_path in reversed(mirrored):
        try:
            shutil.copystat(source_path, destination_path)
        except OSError:
            pass


def preserve_album_art(
    source_track: Path,
    destination_track: Path,
    probe: dict[str, Any],
    archive_artwork: bool,
) -> None:
    album_key = str(source_track.parent)
    with STATE.album_art_lock:
        if album_key in STATE.art_done:
            return

        destination_album = destination_track.parent
        destination_album.mkdir(parents=True, exist_ok=True)
        copied_cover: Path | None = None
        for name in ("cover.jpg", "cover.jpeg", "cover.png", "folder.jpg", "folder.png"):
            candidate = source_track.parent / name
            if candidate.is_file():
                target = destination_album / candidate.name
                if not target.exists():
                    copy_file_atomically(candidate, target)
                copied_cover = target
                break

        video_stream = next(
            (stream for stream in probe.get("streams", []) if stream.get("codec_type") == "video"),
            None,
        )
        if video_stream:
            codec = video_stream.get("codec_name")
            extension = ".png" if codec == "png" else ".jpg"
            front = destination_album / f"cover{extension}"
            if not front.exists():
                temporary = destination_album / f".cover{extension}.partial"
                run_command(
                    [
                        "ffmpeg",
                        "-nostdin",
                        "-v",
                        "error",
                        "-y",
                        "-i",
                        str(source_track),
                        "-map",
                        "0:v:0",
                        "-frames:v",
                        "1",
                        "-c:v",
                        "copy",
                        "-f",
                        "image2",
                        str(temporary),
                    ],
                    timeout=120,
                )
                os.replace(temporary, front)
                copied_cover = front

        if archive_artwork and copied_cover:
            archive = destination_album / ".cover" / f"front{copied_cover.suffix.lower()}"
            if not archive.exists():
                copy_file_atomically(copied_cover, archive)

        STATE.art_done.add(album_key)


def write_metadata_sidecar(
    source_track: Path,
    destination_track: Path,
    probe: dict[str, Any],
    source_dir: Path,
) -> None:
    metadata_dir = destination_track.parent / ".metadata"
    metadata_dir.mkdir(parents=True, exist_ok=True)
    target = metadata_dir / f"{destination_track.stem}.json"
    temporary = metadata_dir / f".{destination_track.stem}.json.partial"
    payload = {
        "source": str(source_track.relative_to(source_dir)),
        "audio": audio_stream(probe),
        "tags": probe.get("format", {}).get("tags", {}),
    }
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    os.replace(temporary, target)


def convert_track(
    track: Track,
    source_dir: Path,
    destination_dir: Path,
    archive_artwork: bool,
    metadata_sidecars: bool,
) -> str:
    if STATE.stop_event.is_set():
        return "stopped"

    source = source_dir / track.source
    destination = destination_dir / track.output
    destination.parent.mkdir(parents=True, exist_ok=True)
    pcm_codec = pcm_codec_for_bits(track.bits)
    probe = probe_file(source)
    preserve_album_art(source, destination, probe, archive_artwork)

    if destination.exists():
        try:
            if decoded_hash(source, pcm_codec) == decoded_hash(destination, pcm_codec):
                if metadata_sidecars:
                    write_metadata_sidecar(source, destination, probe, source_dir)
                return "skipped"
        except Exception:
            pass
        raise RuntimeError("Destination already exists but does not verify")

    temporary = destination.with_name(f".{destination.name}.partial")
    try:
        run_command(
            [
                "ffmpeg",
                "-nostdin",
                "-v",
                "error",
                "-y",
                "-i",
                str(source),
                "-map",
                "0:a:0",
                "-map_metadata",
                "0",
                "-c:a",
                pcm_codec,
                "-rf64",
                "auto",
                "-f",
                "wav",
                str(temporary),
            ],
            timeout=1800,
        )
        source_hash = decoded_hash(source, pcm_codec)
        output_hash = decoded_hash(temporary, pcm_codec)
        if source_hash != output_hash:
            raise RuntimeError("Decoded audio verification failed")
        os.replace(temporary, destination)
        shutil.copystat(source, destination)
        if metadata_sidecars:
            write_metadata_sidecar(source, destination, probe, source_dir)
        return "completed"
    finally:
        temporary.unlink(missing_ok=True)


def run_job(options: dict[str, Any]) -> None:
    selection = selection_from_options(options)
    source_subdir = selection["sourceSubdir"]
    destination_subdir = selection["destinationSubdir"]
    workers = max(1, min(4, int(options.get("workers", 2))))
    archive_artwork = bool(options.get("archiveArtwork", True))
    metadata_sidecars = bool(options.get("metadataSidecars", True))

    try:
        tracks = scan_library(source_subdir, destination_subdir)
        source_dir = safe_subpath(SOURCE_ROOT, source_subdir)
        destination_dir = safe_subpath(DEST_ROOT, destination_subdir)
        STATE.stop_event.clear()
        STATE.art_done.clear()
        STATE.update(
            phase="running",
            message="Losslessly unpacking ALAC to original PCM samples",
            tracks=[asdict(track) for track in tracks],
            total=len(tracks),
            completed=0,
            skipped=0,
            failed=0,
            active=0,
            estimatedBytes=sum(item.estimated_wav_bytes for item in tracks),
            sourceBytes=sum(item.source_bytes for item in tracks),
            startedAt=time.time(),
            finishedAt=None,
            selection=selection,
        )
        STATE.log(f"Started {len(tracks)} tracks with {workers} worker(s)")
        mirrored_directories = mirror_directory_tree(source_dir, destination_dir)
        STATE.log(f"Mirrored {len(mirrored_directories)} folders with their original names")

        with ThreadPoolExecutor(max_workers=workers) as executor:
            futures = {}
            for track in tracks:
                if STATE.stop_event.is_set():
                    break
                future = executor.submit(
                    convert_track,
                    track,
                    source_dir,
                    destination_dir,
                    archive_artwork,
                    metadata_sidecars,
                )
                futures[future] = track

            for future in as_completed(futures):
                track = futures[future]
                try:
                    outcome = future.result()
                    if outcome == "completed":
                        STATE.adjust(completed=1)
                        STATE.set_track_state(track.source, "verified")
                        STATE.log(f"Verified: {track.output}")
                    elif outcome == "skipped":
                        STATE.adjust(skipped=1)
                        STATE.set_track_state(track.source, "verified existing")
                        STATE.log(f"Already verified: {track.output}")
                    elif outcome == "stopped":
                        STATE.set_track_state(track.source, "stopped")
                except Exception as exc:
                    STATE.adjust(failed=1)
                    STATE.set_track_state(track.source, "failed")
                    STATE.log(f"Failed: {track.source} — {exc}", "error")

        preserve_directory_timestamps(mirrored_directories)
        stopped = STATE.stop_event.is_set()
        phase = "stopped" if stopped else "complete"
        message = "Stopped safely; start again to resume" if stopped else "Library mirror complete"
        STATE.update(phase=phase, message=message, active=0, finishedAt=time.time())
        STATE.log(message)
    except Exception as exc:
        STATE.update(phase="error", message=str(exc), finishedAt=time.time())
        STATE.log(str(exc), "error")


def start_job(options: dict[str, Any]) -> None:
    selection = selection_from_options(options)
    with STATE.lock:
        if STATE.job_thread and STATE.job_thread.is_alive():
            raise RuntimeError("A job is already running")
        if STATE.data.get("selection") != selection:
            raise RuntimeError("Preview this folder selection before starting")
        if not options.get("previewToken") or options.get("previewToken") != STATE.data.get(
            "previewToken"
        ):
            raise RuntimeError("This preview is no longer current. Preview the folders again.")
        source_dir = safe_subpath(SOURCE_ROOT, selection["sourceSubdir"])
        destination_dir = safe_subpath(DEST_ROOT, selection["destinationSubdir"])
        claim_destination(source_dir, destination_dir)
        STATE.job_thread = threading.Thread(target=run_job, args=(options,), daemon=True)
        STATE.job_thread.start()


def perform_scan(options: dict[str, Any]) -> dict[str, Any]:
    selection = selection_from_options(options)
    preview_token = uuid.uuid4().hex
    source_dir = safe_subpath(SOURCE_ROOT, selection["sourceSubdir"])
    destination_dir = safe_subpath(DEST_ROOT, selection["destinationSubdir"])
    validate_destination(source_dir, destination_dir)
    tracks = scan_library(
        selection["sourceSubdir"],
        selection["destinationSubdir"],
    )
    STATE.update(
        phase="ready",
        message=f"Ready: {len(tracks)} lossless tracks found",
        tracks=[asdict(track) for track in tracks],
        total=len(tracks),
        completed=0,
        skipped=0,
        failed=0,
        estimatedBytes=sum(item.estimated_wav_bytes for item in tracks),
        sourceBytes=sum(item.source_bytes for item in tracks),
        selection=selection,
        previewToken=preview_token,
    )
    return STATE.snapshot()


class RequestHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, directory=str(STATIC_DIR), **kwargs)

    def log_message(self, format: str, *args: Any) -> None:
        return

    def end_headers(self) -> None:
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def send_json(self, payload: Any, status: int = HTTPStatus.OK) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def read_json(self) -> dict[str, Any]:
        length = int(self.headers.get("Content-Length", "0"))
        if not length:
            return {}
        return json.loads(self.rfile.read(length).decode("utf-8"))

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        route = parsed.path
        if route == "/api/status":
            self.send_json(STATE.snapshot())
            return
        if route == "/api/info":
            self.send_json(
                {
                    "source": str(SOURCE_ROOT),
                    "destination": str(DEST_ROOT),
                    "sourceLabel": SOURCE_LABEL,
                    "destinationLabel": DEST_LABEL,
                    "sourceAvailable": SOURCE_ROOT.is_dir(),
                    "destinationAvailable": DEST_ROOT.is_dir(),
                }
            )
            return
        if route == "/api/folders":
            try:
                query = parse_qs(parsed.query)
                kind = query.get("kind", [""])[0]
                relative = query.get("path", [""])[0]
                self.send_json(folder_listing(kind, relative))
            except Exception as exc:
                self.send_json({"error": str(exc)}, HTTPStatus.BAD_REQUEST)
            return
        super().do_GET()

    def do_POST(self) -> None:
        route = urlparse(self.path).path
        try:
            payload = self.read_json()
            if route == "/api/scan":
                self.send_json(perform_scan(payload))
            elif route == "/api/start":
                start_job(payload)
                self.send_json({"ok": True}, HTTPStatus.ACCEPTED)
            elif route == "/api/stop":
                STATE.stop_event.set()
                STATE.update(message="Stopping safely after current tracks")
                self.send_json({"ok": True})
            elif route == "/api/folders/create":
                self.send_json(
                    create_destination_folder(
                        str(payload.get("path", "")),
                        str(payload.get("name", "")),
                    ),
                    HTTPStatus.CREATED,
                )
            else:
                self.send_json({"error": "Not found"}, HTTPStatus.NOT_FOUND)
        except Exception as exc:
            self.send_json({"error": str(exc)}, HTTPStatus.BAD_REQUEST)


def main() -> None:
    CONFIG_ROOT.mkdir(parents=True, exist_ok=True)
    DEST_ROOT.mkdir(parents=True, exist_ok=True)
    server = ThreadingHTTPServer(("0.0.0.0", PORT), RequestHandler)
    print(f"Lossless Library Mirror is listening on port {PORT}", flush=True)
    server.serve_forever()


if __name__ == "__main__":
    main()
