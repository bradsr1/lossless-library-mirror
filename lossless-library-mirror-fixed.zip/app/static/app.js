const $ = (selector) => document.querySelector(selector);
let latest = { phase: "idle", tracks: [], logs: [] };
let folderBrowser = { kind: "source", current: "" };

function options() {
  return {
    sourceSubdir: $("#sourceSubdir").value.trim(),
    destinationSubdir: $("#destinationSubdir").value.trim(),
    workers: Number($("#workers").value),
    archiveArtwork: $("#archiveArtwork").checked,
    metadataSidecars: $("#metadataSidecars").checked,
    previewToken: latest.previewToken || null,
  };
}

function matchesPreview() {
  const selected = options();
  return latest.selection
    && selected.sourceSubdir === latest.selection.sourceSubdir
    && selected.destinationSubdir === latest.selection.destinationSubdir;
}

async function request(path, body) {
  const response = await fetch(path, {
    method: body === undefined ? "GET" : "POST",
    headers: body === undefined ? {} : { "Content-Type": "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Request failed");
  return data;
}

function bytes(value) {
  if (!value) return "—";
  const units = ["B", "KB", "MB", "GB", "TB"];
  let amount = value;
  let unit = 0;
  while (amount >= 1000 && unit < units.length - 1) { amount /= 1000; unit += 1; }
  return `${amount.toFixed(amount >= 10 || unit === 0 ? 0 : 1)} ${units[unit]}`;
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;",
  })[character]);
}

function render(data) {
  latest = data;
  const done = (data.completed || 0) + (data.skipped || 0) + (data.failed || 0);
  const progress = data.total ? Math.min(100, done / data.total * 100) : 0;
  const running = ["scanning", "running"].includes(data.phase);

  $("#statusMessage").textContent = data.message || "Ready";
  $("#phaseBadge").textContent = data.phase || "idle";
  $("#progressBar").style.width = `${progress}%`;
  $("#trackCount").textContent = data.total || "—";
  $("#completedCount").textContent = (data.completed || 0) + (data.skipped || 0) || "—";
  $("#failedCount").textContent = data.failed || "—";
  $("#sizeEstimate").textContent = bytes(data.estimatedBytes);
  $("#scanButton").disabled = running;
  $("#startButton").disabled = running || !data.total || !matchesPreview();
  $("#stopButton").disabled = data.phase !== "running";

  const tracks = data.tracks || [];
  $("#showingCount").textContent = tracks.length ? `Showing ${Math.min(150, tracks.length)} of ${tracks.length}` : "";
  $("#trackRows").innerHTML = tracks.length
    ? tracks.slice(0, 150).map((track) => `
      <tr>
        <td><span class="track-title">${escapeHtml(track.title)}</span><span class="track-path">${escapeHtml(track.output)}</span></td>
        <td>${track.bits}-bit · ${(track.sample_rate / 1000).toFixed(1)} kHz</td>
        <td class="state">${escapeHtml(track.state)}</td>
      </tr>`).join("")
    : '<tr><td colspan="3" class="empty">Preview the library to see its tracks.</td></tr>';

  const logs = data.logs || [];
  $("#logs").innerHTML = logs.length
    ? [...logs].reverse().map((entry) => `
      <div class="log ${escapeHtml(entry.level)}"><time>${escapeHtml(entry.time)}</time><p>${escapeHtml(entry.message)}</p></div>`).join("")
    : '<p class="empty">Nothing to report yet.</p>';
}

async function refresh() {
  try { render(await request("/api/status")); } catch (_) {}
}

async function loadFolders(kind, path = "") {
  const data = await request(`/api/folders?kind=${encodeURIComponent(kind)}&path=${encodeURIComponent(path)}`);
  folderBrowser = { kind: data.kind, current: data.current, parent: data.parent };
  $("#folderKindLabel").textContent = data.kind === "source" ? "NAS source" : "NAS destination";
  $("#folderDialogTitle").textContent = data.kind === "source" ? "Choose ALAC folder" : "Choose WAV destination";
  $("#currentFolder").textContent = data.current ? `/${data.current}` : "/";
  $("#folderUp").disabled = data.parent === null;
  $("#showCreateFolder").hidden = !data.canCreate;
  $("#createFolderRow").hidden = true;
  $("#newFolderName").value = "";
  $("#folderList").innerHTML = data.folders.length
    ? data.folders.map((folder) => `<button class="folder-item" type="button" data-path="${escapeHtml(folder.path)}">${escapeHtml(folder.name)}</button>`).join("")
    : '<div class="folder-empty">No subfolders here</div>';
}

async function openFolderBrowser(kind) {
  const value = kind === "source" ? $("#sourceSubdir").value : $("#destinationSubdir").value;
  try {
    await loadFolders(kind, value);
    $("#folderDialog").showModal();
  } catch (error) { alert(error.message); }
}

$("#browseSource").addEventListener("click", () => openFolderBrowser("source"));
$("#browseDestination").addEventListener("click", () => openFolderBrowser("destination"));
$("#folderList").addEventListener("click", async (event) => {
  const button = event.target.closest(".folder-item");
  if (!button) return;
  try { await loadFolders(folderBrowser.kind, button.dataset.path); }
  catch (error) { alert(error.message); }
});
$("#folderUp").addEventListener("click", async () => {
  try { await loadFolders(folderBrowser.kind, folderBrowser.parent ?? ""); }
  catch (error) { alert(error.message); }
});
$("#chooseFolder").addEventListener("click", () => {
  const target = folderBrowser.kind === "source" ? $("#sourceSubdir") : $("#destinationSubdir");
  target.value = folderBrowser.current;
  $("#folderDialog").close();
  render(latest);
});
$("#showCreateFolder").addEventListener("click", () => {
  $("#createFolderRow").hidden = false;
  $("#newFolderName").focus();
});
$("#createFolderButton").addEventListener("click", async () => {
  try {
    const data = await request("/api/folders/create", {
      path: folderBrowser.current,
      name: $("#newFolderName").value,
    });
    $("#destinationSubdir").value = data.current;
    $("#folderDialog").close();
    render(latest);
  } catch (error) { alert(error.message); }
});
$("#cancelFolder").addEventListener("click", () => $("#folderDialog").close());
$("#closeFolderDialog").addEventListener("click", () => $("#folderDialog").close());

$("#scanButton").addEventListener("click", async () => {
  try { render(await request("/api/scan", options())); }
  catch (error) { alert(error.message); await refresh(); }
});

$("#startButton").addEventListener("click", async () => {
  const selected = options();
  const source = selected.sourceSubdir ? `/${selected.sourceSubdir}` : "/";
  const destination = selected.destinationSubdir ? `/${selected.destinationSubdir}` : "/";
  const message = [
    `Losslessly unpack ${latest.total} track${latest.total === 1 ? "" : "s"} to WAV?`,
    "",
    `FROM: ${source}`,
    `TO: ${destination}`,
    "",
    "Existing files will be preserved. Conflicting WAV files will never be overwritten.",
  ].join("\n");
  if (latest.total && !confirm(message)) return;
  try { await request("/api/start", options()); await refresh(); }
  catch (error) { alert(error.message); }
});

$("#stopButton").addEventListener("click", async () => {
  try { await request("/api/stop", {}); await refresh(); }
  catch (error) { alert(error.message); }
});

["#sourceSubdir", "#destinationSubdir"].forEach((selector) => {
  $(selector).addEventListener("input", () => render(latest));
});

(async () => {
  try {
    const info = await request("/api/info");
    $("#sourceMount").textContent = info.sourceLabel || info.source;
    $("#destinationMount").textContent = info.destinationLabel || info.destination;
  } catch (_) {}
  await refresh();
  setInterval(refresh, 1200);
})();
