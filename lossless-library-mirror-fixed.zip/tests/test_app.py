import importlib.util
import sys
import tempfile
import unittest
import json
from pathlib import Path


APP_PATH = Path(__file__).parents[1] / "app" / "app.py"
SPEC = importlib.util.spec_from_file_location("mirror_app", APP_PATH)
APP = importlib.util.module_from_spec(SPEC)
assert SPEC.loader
sys.modules[SPEC.name] = APP
SPEC.loader.exec_module(APP)


class MirrorTests(unittest.TestCase):
    def test_pcm_codec_preserves_expected_depth(self):
        self.assertEqual(APP.pcm_codec_for_bits(16), "pcm_s16le")
        self.assertEqual(APP.pcm_codec_for_bits(20), "pcm_s24le")
        self.assertEqual(APP.pcm_codec_for_bits(24), "pcm_s24le")
        self.assertEqual(APP.pcm_codec_for_bits(32), "pcm_s32le")

    def test_safe_subpath_accepts_children(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory).resolve()
            self.assertEqual(APP.safe_subpath(root, "Artist/Album"), root / "Artist/Album")

    def test_safe_subpath_rejects_parent_escape(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory).resolve()
            with self.assertRaises(ValueError):
                APP.safe_subpath(root, "../outside")

    def test_selection_is_normalized_before_preview_comparison(self):
        self.assertEqual(
            APP.selection_from_options(
                {"sourceSubdir": " /Artist/Album/ ", "destinationSubdir": " WAV/ "}
            ),
            {"sourceSubdir": "Artist/Album", "destinationSubdir": "WAV"},
        )

    def test_directory_tree_is_mirrored_exactly(self):
        with tempfile.TemporaryDirectory() as source_directory, tempfile.TemporaryDirectory() as destination_directory:
            source = Path(source_directory)
            destination = Path(destination_directory)
            (source / "Artist & Friends" / "Disc 2 [2025]" / "Empty folder").mkdir(parents=True)
            APP.mirror_directory_tree(source, destination)
            self.assertTrue(
                (destination / "Artist & Friends" / "Disc 2 [2025]" / "Empty folder").is_dir()
            )

    def test_folder_listing_hides_internal_dot_folders(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "Visible artist").mkdir()
            (root / ".metadata").mkdir()
            original_root = APP.SOURCE_ROOT
            APP.SOURCE_ROOT = root.resolve()
            try:
                listing = APP.folder_listing("source")
                self.assertEqual([item["name"] for item in listing["folders"]], ["Visible artist"])
            finally:
                APP.SOURCE_ROOT = original_root

    def test_claim_destination_accepts_empty_folder_and_writes_marker(self):
        with tempfile.TemporaryDirectory() as source_directory, tempfile.TemporaryDirectory() as destination_directory:
            source = Path(source_directory)
            destination = Path(destination_directory)
            APP.claim_destination(source, destination)
            marker = destination / APP.DESTINATION_MARKER
            self.assertTrue(marker.is_file())
            self.assertEqual(json.loads(marker.read_text())["source"], str(source.resolve()))

    def test_claim_destination_adopts_unclaimed_nonempty_folder(self):
        with tempfile.TemporaryDirectory() as source_directory, tempfile.TemporaryDirectory() as destination_directory:
            destination = Path(destination_directory)
            (destination / "existing-album").mkdir()
            APP.claim_destination(Path(source_directory), destination)
            marker = json.loads((destination / APP.DESTINATION_MARKER).read_text())
            self.assertTrue(marker["adoptedExistingFolder"])
            self.assertTrue((destination / "existing-album").is_dir())

    def test_claim_destination_allows_resume_for_same_source(self):
        with tempfile.TemporaryDirectory() as source_directory, tempfile.TemporaryDirectory() as destination_directory:
            source = Path(source_directory)
            destination = Path(destination_directory)
            APP.claim_destination(source, destination)
            (destination / "Artist").mkdir()
            APP.claim_destination(source, destination)

    def test_claim_destination_rejects_marker_for_different_source(self):
        with tempfile.TemporaryDirectory() as first_source, tempfile.TemporaryDirectory() as second_source, tempfile.TemporaryDirectory() as destination_directory:
            destination = Path(destination_directory)
            APP.claim_destination(Path(first_source), destination)
            with self.assertRaisesRegex(ValueError, "different source"):
                APP.claim_destination(Path(second_source), destination)


if __name__ == "__main__":
    unittest.main()
